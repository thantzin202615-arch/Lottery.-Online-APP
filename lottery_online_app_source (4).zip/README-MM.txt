Lottery Online App - စတင်အသုံးပြုရန်
=======================================

ဒီ ZIP ထဲမှာ
- server.js                 Backend API + SQLite Database
- public/index.html         User စာမျက်နှာ (ဖုန်းအတွက် responsive)
- public/admin.html         Admin Dashboard
- capacitor.config.json     Android APK wrapper setting
- .env.example              လျှို့ဝှက် Password/Server setting နမူနာ

အရေးကြီး
--------
ဒီ Project က စာရင်းမှတ်တမ်းစနစ်ဖြစ်ပြီး ငွေပေးချေမှု/ငွေလွှဲစနစ် မပါဝင်ပါ။
Internet ပေါ်တင်မည်ဆိုလျှင် HTTPS ပါသော Hosting သုံးပါ။
Admin Password ကို Code ထဲမထည့်ဘဲ Environment Variable မှာ သတ်မှတ်ထားပါ။
မူလ Password 123456 ကို မသုံးပါနှင့်။

Server စတင်ရန်
--------------
1. Node.js LTS တင်ပါ။
2. Project folder ထဲမှာ npm install လုပ်ပါ။
3. .env.example ကို .env အဖြစ်ကူးပြီး ADMIN_PASSWORD နှင့် SESSION_SECRET ကို ပြောင်းပါ။
   SESSION_SECRET ကို အနည်းဆုံး အက္ခရာ 32 လုံး ကျပန်းသတ်မှတ်ပါ။
4. npm start ဖြင့် စတင်ပါ။
5. Browser မှ http://localhost:3000 ကိုဖွင့်ပါ။
   Admin: http://localhost:3000/admin

APK အတွက်
---------
Android APK ကို Online အသုံးပြုရန် Hosting Domain (HTTPS) လိုအပ်ပါသည်။
Hosting မတင်ရသေးလျှင် APK ထဲမှာ ထည့်မည့် URL မရှိသေးပါ။
Domain ရပြီးမှ capacitor.config.json ထဲက YOUR-HOSTED-DOMAIN.example ကို အစားထိုးပါ။
ပြီးလျှင် android-wrapper/README.txt ထဲက အဆင့်များအတိုင်း Android Studio မှ APK Build လုပ်ပါ။

လုံခြုံရေး
---------
- Admin API များကို Token ဖြင့် ကာကွယ်ထားသည်။
- Password ကို Environment Variable မှာထားသည်။
- ထည့်သွင်းသည့် နံပါတ်နှင့် ငွေပမာဏကို Server ဘက်မှ စစ်ဆေးသည်။
- API rate limit ထည့်ထားသည်။
- Database update ကို transaction ဖြင့် လုပ်ဆောင်သည်။
- Production တွင် Database backup ပုံမှန်လုပ်ပါ။
