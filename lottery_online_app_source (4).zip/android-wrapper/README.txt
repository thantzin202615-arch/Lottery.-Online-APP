Android APK wrapper notes
-------------------------
This folder documents the Capacitor wrapper setup. The Android project is generated after deployment:

1. Install Node.js LTS and Android Studio.
2. In the project root run:
   npm install
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap add android
3. Replace YOUR-HOSTED-DOMAIN.example in capacitor.config.json with your real HTTPS domain.
4. Run:
   npx cap sync android
   npx cap open android
5. In Android Studio choose Build > Build Bundle(s) / APK(s) > Build APK(s).

The APK loads the hosted site, so the server must be online and use HTTPS.
Do not publish an APK with the placeholder URL.
