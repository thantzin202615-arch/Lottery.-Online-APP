const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
const DB_FILE = process.env.DATABASE_FILE || "./data/lottery.db";

if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 12) {
  throw new Error("Set ADMIN_PASSWORD in environment (minimum 12 characters).");
}
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  throw new Error("Set SESSION_SECRET in environment (minimum 32 characters).");
}

fs.mkdirSync(path.dirname(path.resolve(DB_FILE)), { recursive: true });
const db = new Database(DB_FILE);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS votes (
    number TEXT PRIMARY KEY CHECK(length(number) = 2 AND number GLOB '[0-9][0-9]'),
    total_amount INTEGER NOT NULL DEFAULT 0 CHECK(total_amount >= 0)
  );
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS bet_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    number TEXT NOT NULL,
    amount INTEGER NOT NULL CHECK(amount > 0),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

const insertNumber = db.prepare("INSERT OR IGNORE INTO votes(number, total_amount) VALUES (?, 0)");
const seed = db.transaction(() => {
  for (let i = 0; i < 100; i++) insertNumber.run(String(i).padStart(2, "0"));
  db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES('is_closed','false')").run();
  db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES('winning_number','-')").run();
});
seed();

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const betLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });

function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function sign(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = crypto.createHmac("sha256", SESSION_SECRET).update(body).digest("base64url");
  return `${body}.${sig}`;
}
function verifyToken(token) {
  if (!token || typeof token !== "string") return null;
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  const expected = crypto.createHmac("sha256", SESSION_SECRET).update(parts[0]).digest("base64url");
  if (!safeEqual(parts[1], expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(parts[0], "base64url").toString());
    if (!payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch { return null; }
}
function requireAdmin(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!verifyToken(token)) return res.status(401).json({ success: false, message: "Admin အကောင့်ဝင်ရန် လိုအပ်ပါသည်။" });
  next();
}
function getSettings() {
  return Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x => [x.key, x.value]));
}

app.get("/api/health", (req, res) => res.json({ success: true, service: "online" }));
app.get("/api/bets", (req, res) => {
  const rows = db.prepare("SELECT number,total_amount FROM votes ORDER BY number").all();
  const grid = {};
  rows.forEach(r => grid[r.number] = r.total_amount);
  res.json(grid);
});
app.get("/api/status", (req, res) => res.json(getSettings()));

app.post("/api/bet", betLimiter, (req, res) => {
  const number = String(req.body?.number ?? "");
  const amount = Number(req.body?.amount);
  if (!/^\d{2}$/.test(number)) return res.status(400).json({ success: false, message: "နံပါတ်ကို 00 မှ 99 အတွင်း ရွေးပါ။" });
  if (!Number.isSafeInteger(amount) || amount < 1 || amount > 100000000) {
    return res.status(400).json({ success: false, message: "ငွေပမာဏ မမှန်ပါ။" });
  }
  if (getSettings().is_closed === "true") return res.status(409).json({ success: false, message: "ထီပိတ်သွားပါပြီ။" });
  const addBet = db.transaction(() => {
    const exists = db.prepare("SELECT number FROM votes WHERE number=?").get(number);
    if (!exists) throw new Error("INVALID_NUMBER");
    db.prepare("UPDATE votes SET total_amount=total_amount+? WHERE number=?").run(amount, number);
    db.prepare("INSERT INTO bet_log(number,amount) VALUES(?,?)").run(number, amount);
  });
  try {
    addBet();
    res.json({ success: true, message: "စာရင်းသွင်းခြင်း အောင်မြင်ပါသည်။" });
  } catch (e) {
    res.status(400).json({ success: false, message: "စာရင်းသွင်း၍ မရပါ။" });
  }
});

app.post("/api/admin/login", loginLimiter, (req, res) => {
  if (!safeEqual(req.body?.password || "", ADMIN_PASSWORD)) {
    return res.status(401).json({ success: false, message: "Admin Password မှားယွင်းနေပါသည်။" });
  }
  const token = sign({ role: "admin", exp: Date.now() + 8 * 60 * 60 * 1000 });
  res.json({ success: true, token });
});
app.get("/api/admin/summary", requireAdmin, (req, res) => {
  const bets = db.prepare("SELECT number,total_amount FROM votes ORDER BY total_amount DESC, number ASC").all();
  const total = db.prepare("SELECT COALESCE(SUM(total_amount),0) AS total FROM votes").get().total;
  const recent = db.prepare("SELECT number,amount,created_at FROM bet_log ORDER BY id DESC LIMIT 30").all();
  res.json({ total, bets, recent, status: getSettings() });
});
app.post("/api/admin/toggle", requireAdmin, (req, res) => {
  const value = req.body?.is_closed;
  if (typeof value !== "boolean") return res.status(400).json({ success: false, message: "အခြေအနေ မမှန်ပါ။" });
  db.prepare("UPDATE settings SET value=? WHERE key='is_closed'").run(String(value));
  res.json({ success: true });
});
app.post("/api/admin/draw", requireAdmin, (req, res) => {
  const number = String(req.body?.winning_number ?? "");
  if (!/^\d{2}$/.test(number)) return res.status(400).json({ success: false, message: "ပေါက်ဂဏန်းကို 00 မှ 99 အတွင်း ထည့်ပါ။" });
  db.prepare("UPDATE settings SET value=? WHERE key='winning_number'").run(number);
  res.json({ success: true, message: "ပေါက်ဂဏန်း ထုတ်ပြန်ပြီးပါပြီ။" });
});
app.post("/api/admin/reset", requireAdmin, (req, res) => {
  const reset = db.transaction(() => {
    db.prepare("UPDATE votes SET total_amount=0").run();
    db.prepare("DELETE FROM bet_log").run();
    db.prepare("UPDATE settings SET value='-' WHERE key='winning_number'").run();
  });
  reset();
  res.json({ success: true, message: "စာရင်းရှင်းလင်းပြီးပါပြီ။" });
});

app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Lottery app listening on port ${PORT}`));
